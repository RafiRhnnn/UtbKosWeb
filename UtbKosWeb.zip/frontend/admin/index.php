<?php
// Mengarahkan ke frontend/index.php
header("Location: dashboard.php");
exit;