<footer class="bg-dark text-white text-center py-3" style="margin-top: auto;">
    <p>&copy; 2025 Utbkos. Kelompok 1. Kelas TIF 22 CID. UAS WEB 1</p>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="d-flex justify-content-center gap-3 flex-nowrap">
                    <p class="m-0">Muhammad Rafi Raihan (22552011233)</p>
                    <p class="m-0">Moch Ikhsan Futra M (22552011086)</p>
                    <p class="m-0">Ahmad Zaenal (22552011083)</p>
                    <p class="m-0">Ikbal Julianto (22552011067)</p>
                    <p class="m-0">Yushela Windy Anggraeni (21552011002)</p>
                </div>
            </div>
        </div>
    </div>
</footer>