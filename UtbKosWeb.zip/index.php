<?php
// Mengarahkan ke frontend/index.php
header("Location: frontend/index.php");
exit;